package com.cts.messages;

import org.springframework.jms.core.JmsTemplate;

public class MessageProducer {

	private JmsTemplate jmsTemplate;

	public void setJmsTemplate(JmsTemplate jmsTemplate) {
		this.jmsTemplate = jmsTemplate;
	}
	
	public void sendMessage(Object obj)
	{
		jmsTemplate.convertAndSend(obj);
	}
	
}

package com.cts.messages;

import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.MapMessage;

import org.springframework.jms.core.JmsTemplate;

public class MessageConsumer {

	private JmsTemplate jmsTemplate;
	private Destination destination;
	public Destination getDestination() {
		return destination;
	}
	public void setDestination(Destination destination) {
		this.destination = destination;
	}
	public JmsTemplate getJmsTemplate() {
		return jmsTemplate;
	}
	public void setJmsTemplate(JmsTemplate jmsTemplate) {
		this.jmsTemplate = jmsTemplate;
	}
	
	public MapMessage receiveMessage()  {
		MapMessage mapMessage = (MapMessage) jmsTemplate.receive(destination);		
		return mapMessage;
	}
	
}

package com.cts.utility;

import java.util.HashMap;
import java.util.Map;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cts.messages.MessageProducer;

public class MainApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       ApplicationContext ctx =new ClassPathXmlApplicationContext("spring.xml");
       MessageProducer producer= (MessageProducer) ctx.getBean("messageProducer");
       Map message = new HashMap();
		  message.put("Spring", "JMS");
		  message.put("country", "India");
		  message.put("state", "TamilNadu");
		  message.put("city", "Chennai");
		  producer.sendMessage(message);
	}

}
